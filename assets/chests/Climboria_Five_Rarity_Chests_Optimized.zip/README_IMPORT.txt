CLIMBORIA — 5 optimized rarity chest assets

Upload the five .glb files from assets/chests/ to the same paths in
GitHub branch game/chest-rarity-glb-models-2026-11-15 (NOT directly to main).

This ZIP is a transport package. Do not upload the ZIP itself as a game asset.
The exact SHA-256 digests and byte counts are in manifest.json.
The code PR must not merge until GitHub exact-head CI and game 3D tests pass.
All world/cave/summit drop probabilities remain unchanged.
